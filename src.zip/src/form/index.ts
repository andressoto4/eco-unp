export { default as ContactoPersona } from './ContactoPersona';
export { default as NombrePersona } from './NombrePersona';
export { default as Nuip } from './Nuip';
export { default as UbicacionPersona } from './UbicacionPersona';