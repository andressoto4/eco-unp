import React from "react";

import { FaBell } from "react-icons/fa";

const NotificacionUsuario = () => {
    return (
        <FaBell style={{ width: '25px', height: '25px' }} />
    );
};

export default NotificacionUsuario;