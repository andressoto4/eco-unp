export interface IdUsuarioContextType {
    idUsuario: string;
    setIdUsuario: (id: string) => void;
}

export interface IdContrasegnaContextType {
    idContrasegna: string;
    setIdContrasegna: (contrasegna: string) => void;
}